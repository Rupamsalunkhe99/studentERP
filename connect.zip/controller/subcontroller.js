const connection=require('./database');


module.exports ={

    getAllstudents:(callback) => {
     connection.query(`SELECT * FROM subject`,(err, result)=>{
         if(err){
         console.log(err); 
        }
         else{
             callback(result);
         }
     })
    },
    getById:(Id,callback) => {
        connection.query(`SELECT sub_id, sub_name, FACulty_id FROM subject where sub_id=${Id}`,(err, result)=>{
            if(err){
            console.log(err);
           }
            else{
                callback(result);
            }
        })
       },
    
       addNewStudent:(data,callback) => {
        connection.query(`INSERT INTO subject(sub_id, sub_name, FACulty_id) VALUES (0,'${data.Name}','${data.Faculty_id}')`,(err, result) => {
            if(err){
                console.log(err);
            }else{
                callback(result);  
            }
        })
    },    
    deleteById:(Id,callback) => {
        connection.query(`DELETE FROM subject WHERE sub_id=${Id}`,(err, result) => {
            if(err){
                console.log(err);
            }else{
                callback(result);  
            }
        })
    },     
    updateStudent:(Id,data,callback) => {
        connection.query(`UPDATE subject SET sub_id='${data.Id}',sub_name='${data.Name}',FACulty_id='${data.Faculty_id}' WHERE sub_id='${Id}'`,(err, result) => {
            if(err){
                console.log(err);
            
            }else{
                callback(result);  
            }
        })
    },
}