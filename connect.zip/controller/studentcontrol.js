const connection=require('./database');


module.exports ={

    getAllstudents:(callback) => {
     connection.query(`SELECT * FROM student2`,(err, result)=>{
         if(err){
         console.log(err); 
        }
         else{
             callback(result);
         }
     })
    },
    getById:(Id,callback) => {
        connection.query(`SELECT Stud_id, Name, dept_id FROM student2 WHERE Stud_id=${Id}`,(err, result)=>{
            if(err){
            console.log(err);
           }
            else{
                callback(result);
            }
        })
       },
    
       addNewStudent:(data,callback) => {
        connection.query(`INSERT INTO student2(Stud_id, Name,dept_id) VALUES (0,'${data.Name}',${data.dept_id})`,(err, result) => {
            if(err){
                console.log(err);
            }else{
                callback(result);  
            }
        })
    },    
    deleteById:(Id,callback) => {
        connection.query(`DELETE FROM student2 WHERE Stud_id=${Id}`,(err, result) => {
            if(err){
                console.log(err);
            }else{
                callback(result);  
            }
        })
    },     
    updateStudent:(Id,data,callback) => {
        connection.query(`UPDATE student2 SET Stud_id='${data.Stud_id}',Name='${data.Name}' WHERE Stud_id='${Id}'`,(err, result) => {
            if(err){
                console.log(err);
            
            }else{
                callback(result);  
            }
        })
    },


}