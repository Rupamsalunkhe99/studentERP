const connection=require('./database');


module.exports ={

    getAllstudents:(callback) => {
     connection.query(`SELECT * FROM department`,(err, result)=>{
         if(err){
         console.log(err); 
        }
         else{
             callback(result);
         }
     })
    },
    getById:(Id,callback) => {
        connection.query(`SELECT department_id, department_name FROM department WHERE department_id=${Id}`,(err, result)=>{
            if(err){
            console.log(err);
           }
            else{
                callback(result);
            }
        })
       },
    
       addNewStudent:(data,callback) => {
        connection.query(`INSERT INTO department(department_id, department_name) VALUES ('${data.department_id}','${data.department_name}')`,(err, result) => {
            if(err){
                console.log(err);
            }else{
                callback(result);  
            }
        })
    },    
    deleteById:(Id,callback) => {
        connection.query(`DELETE FROM department WHERE department_id=${Id}`,(err, result) => {
            if(err){
                console.log(err);
            }else{
                callback(result);  
            }
        })
    },     
    updateStudent:(Id,data,callback) => {
        connection.query(`UPDATE department SET department_name='${data.department_name}' WHERE department_id='${Id}'`,(err, result) => {
            if(err){
                console.log(err);
            
            }else{
                callback(result);  
            }
        })
    },
}