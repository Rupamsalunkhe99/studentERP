const connection=require('./database');


module.exports ={

    getAllstudents:(callback) => {
     connection.query(`SELECT * FROM faculty`,(err, result)=>{
         if(err){
         console.log(err); 
        }
         else{
             callback(result);
         }
     })
    },
    getById:(id,callback) => {
        connection.query(`SELECT faculty_id, faculty_Name, faculty_Mob, dept_id FROM faculty WHERE faculty_id=${id}`,(err, result)=>{
            if(err){
            console.log(err);
           }
            else{
                callback(result);
            }
        })
       },
    
       addNewStudent:(data,callback) => {
        connection.query(`INSERT INTO faculty(faculty_id, faculty_Name, faculty_Mob, dept_id) VALUES (0,'${data.faculty_Name}','${data.faculty_Mob}','${data.dept_id}')`,(err, result) => {
            if(err){
                console.log(err);
            }else{
                callback(result);  
            }
        })
    },    
    deleteById:(Id,callback) => {
        connection.query(`DELETE FROM faculty WHERE faculty_id=${Id}`,(err, result) => {
            if(err){
                console.log(err);
            }else{
                callback(result);  
            }
        })
    },     
    updateStudent:(Id,data,callback) => {
        connection.query(`UPDATE faculty SET faculty_id='${data.faculty_id}',faculty_name='${data.faculty_Name}',faculty_Mob='${data.faculty_Mob}',dept_id='${data.dept_id}' WHERE faculty_id='${Id}'`,(err, result) => {
            if(err){
                console.log(err);
            
            }else{
                callback(result);  
            }
        })
    },
}