let mysql=require('mysql');
let connection=mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'',
    database:'project'
})
connection.connect((err)=>{
    if(err)
    {
        console.log(err);

    }
    else{
        console.log('connection establisheb');
}
})
module.exports=connection;
