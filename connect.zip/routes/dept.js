var express = require('express');
var router = express.Router();
let deptcontrol=require('../controller/deptcontrol');
router.get('/',(req,res,next)=>{
    deptcontrol.getAllstudents((department)=>{
      res.send({error:false,data:department});
  
    })
  });
  
  router.post('/find',(req,res,next)=>{
    let Id=req.body.Id
    deptcontrol.getById(Id,(department)=>{
    
      res.send({error:false,data:department});
   
  
    })
  });
  router.post('/create',(req,res,next)=>{
    deptcontrol.addNewStudent(req.body,(department)=>{
  
    res.send({error:false,data:department})

  

    
  })
  });  
  router.post('/delete',(req,res,next)=>{
    let Id=req.body.Id
    deptcontrol.deleteById(Id ,(department)=>{
      (department.affectedRows > 0) ?
      res.send({error:false,message:"department data deleted"})
      :
      res.send({error:false,message:"department data not found for  delete"});
    }) 
  });
  router.post('/update/:Id',(req, res, next) => {
    let Id = req.params.Id; 
    deptcontrol.updateStudent(Id,req.body,(department) => {
  {      res.send({ error: false, message: "department record updated successfully" })
      }
    })
  });
   
  module.exports = router;
  