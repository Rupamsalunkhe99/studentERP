var express = require('express');
var router = express.Router();
let studentcontrol=require('../controller/studentcontrol');
/* GET users listing. */
router.get('/',(req,res,next)=>{
  studentcontrol.getAllstudents((student2)=>{
    res.send({error:false,data:student2});

  })
});

router.post('/find',(req,res,next)=>{
  let Id=req.body.Id
  studentcontrol.getById(Id,(student2)=>{
  
    res.send({error:false,data:student2});
 

  })
});
router.post('/create',(req,res,next)=>{
  studentcontrol.addNewStudent(req.body,(student2)=>{
    if (student2.affectedRows > 0){
      res.send({error:false,message: "Student record added successfully"})

    }
})
});  
router.post('/delete',(req,res,next)=>{
  let Id=req.body.Id
  studentcontrol.deleteById(Id ,(student2)=>{
    (student2.affectedRows > 0) ?
    res.send({error:false,message:"student data deleted"})
    :
    res.send({error:false,message:"student data not found for  delete"});
  }) 
});
router.post('/update/:Id',(req, res, next) => {
  let Id = req.params.Id; 
  studentcontrol.updateStudent(Id,req.body,(student2) => {
{      res.send({ error: false, message: "Student record updated successfully" })
    }
  })
});
 
module.exports = router;
