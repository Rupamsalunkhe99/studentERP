var express = require('express');
var router = express.Router();
let subcontroller=require('../controller/subcontroller');

router.get('/',(req,res,next)=>{
    subcontroller.getAllstudents((subject)=>{
      res.send({error:false,data:subject});
  
    })
  });
  
  router.post('/find',(req,res,next)=>{
    let Id=req.body.Id
    subcontroller.getById(Id,(subject)=>{
    
      res.send({error:false,data:subject});
   
  
    })
  });
  router.post('/create',(req,res,next)=>{
    subcontroller.addNewStudent(req.body,(subject)=>{
  if(subject.affectedRows > 0){
    res.send({error:false,message: "subject record added successfully"});

  }  
  })
  });  
  router.post('/delete',(req,res,next)=>{
    let Id=req.body.Id
    subcontroller.deleteById(Id ,(subject)=>{
      (subject.affectedRows > 0) ?
      res.send({error:false,message:"subject data deleted"})
      :
      res.send({error:false,message:"subject data not found for  delete"});
    }) 
  });
  router.post('/update/:Id',(req, res, next) => {
    let Id = req.params.Id; 
    subcontroller.updateStudent(Id,req.body,(subject) => {
  {      res.send({ error: false, message: "subject record updated successfully" })
      }
    })
  });

   
  module.exports = router;
  
  