var express = require('express');
var router = express.Router();
let faculcontroller=require('../controller/faculcontroller');
router.get('/',(req,res,next)=>{
    faculcontroller.getAllstudents((faculty)=>{
      res.send({error:false,data:faculty});
  
    })
  });
  
  router.post('/find',(req,res,next)=>{
    let id=req.body.id
    faculcontroller.getById(id,(faculty)=>{
      res.send({error:false,data:faculty});
})
  });
  router.post('/create',(req,res,next)=>{
    faculcontroller.addNewStudent(req.body,(faculty)=>{
  if(faculty.affectedRows > 0){
    res.send({error:false,message:"faculty data created successfully"});    

  }
  })
  });  
  router.post('/delete',(req,res,next)=>{
    let Id=req.body.Id
    faculcontroller.deleteById(Id ,(faculty)=>{
      (faculty.affectedRows > 0) ?
      res.send({error:false,message:"faculty data deleted"})
      :
      res.send({error:false,message:"faculty data not found for  delete"});
    }) 
  });
  router.post('/update/:Id',(req, res, next) => {
    let Id = req.params.Id; 
    faculcontroller.updateStudent(Id,req.body,(faculty) => {
  {      res.send({ error: false, message: "faculty record updated successfully" })
      }
    })
  });
   
  module.exports = router;
  